import java.util.*;

/**
 * SmartMapNavigator.java
 * -----------------------
 * Entry point.
 *
 * Workflow:
 * Start -> Load Graph -> Show Menu -> User Selects Option ->
 * Perform Graph Operation -> Display Result -> Repeat -> Exit
 */
public class SmartMapNavigator {

    private static final String MENU = "\n"
            + "======================================\n"
            + "       SMART MAP NAVIGATOR\n"
            + "======================================\n"
            + " City Management\n"
            + "  1. Add City\n"
            + "  2. Remove City\n"
            + "  3. Display Cities\n"
            + "\n"
            + " Road Management\n"
            + "  4. Add Road\n"
            + "  5. Remove Road\n"
            + "  6. Display Roads\n"
            + "\n"
            + " Navigation\n"
            + "  7. Find Shortest Path (Dijkstra)\n"
            + "\n"
            + " Traversal\n"
            + "  8. BFS Traversal\n"
            + "  9. DFS Traversal\n"
            + "\n"
            + " Graph Analysis\n"
            + "  10. Show Neighbor Cities\n"
            + "  11. Connectivity Check\n"
            + "  12. Connected Components\n"
            + "  13. Total Cities\n"
            + "  14. Total Roads\n"
            + "\n"
            + "  0. Exit\n"
            + "======================================\n";

    /** Pre-load the example map from the project spec. */
    private static CityGraph loadSampleGraph() {
        CityGraph graph = new CityGraph();
        for (String city : new String[]{"Delhi", "Noida", "Gurgaon", "Faridabad", "Agra"}) {
            graph.addCity(city);
        }
        graph.addRoad("Delhi", "Noida", 10);
        graph.addRoad("Delhi", "Gurgaon", 20);
        graph.addRoad("Gurgaon", "Faridabad", 15);
        graph.addRoad("Delhi", "Agra", 200);
        graph.addRoad("Noida", "Agra", 180);
        return graph;
    }

    private static void printRoute(GraphAlgorithms.PathResult result) {
        if (result.path == null) {
            System.out.println("\n[RESULT] No route exists between the given cities.");
            return;
        }
        System.out.println("\n--- Shortest Route ---");
        System.out.println(String.join("\n  \u2193\n", result.path));
        System.out.println("\nDistance = " + result.distance + " KM");
    }

    public static void main(String[] args) {
        System.out.println("Loading Graph...");
        CityGraph graph = loadSampleGraph();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println(MENU);
            System.out.print("Select an option: ");
            String choice = scanner.nextLine().trim();

            switch (choice) {
                case "1": {
                    System.out.print("Enter city name: ");
                    graph.addCity(scanner.nextLine().trim());
                    break;
                }
                case "2": {
                    System.out.print("Enter city name to remove: ");
                    graph.removeCity(scanner.nextLine().trim());
                    break;
                }
                case "3":
                    graph.displayCities();
                    break;
                case "4": {
                    System.out.print("From city: ");
                    String c1 = scanner.nextLine().trim();
                    System.out.print("To city: ");
                    String c2 = scanner.nextLine().trim();
                    System.out.print("Distance (KM): ");
                    try {
                        double dist = Double.parseDouble(scanner.nextLine().trim());
                        graph.addRoad(c1, c2, dist);
                    } catch (NumberFormatException e) {
                        System.out.println("[ERROR] Distance must be a number.");
                    }
                    break;
                }
                case "5": {
                    System.out.print("From city: ");
                    String c1 = scanner.nextLine().trim();
                    System.out.print("To city: ");
                    String c2 = scanner.nextLine().trim();
                    graph.removeRoad(c1, c2);
                    break;
                }
                case "6":
                    graph.displayRoads();
                    break;
                case "7": {
                    System.out.print("Source: ");
                    String src = scanner.nextLine().trim();
                    System.out.print("Destination: ");
                    String dest = scanner.nextLine().trim();
                    GraphAlgorithms.PathResult result = GraphAlgorithms.dijkstra(graph, src, dest);
                    printRoute(result);
                    break;
                }
                case "8": {
                    System.out.print("Start city for BFS: ");
                    String start = scanner.nextLine().trim();
                    List<String> order = GraphAlgorithms.bfs(graph, start);
                    if (!order.isEmpty()) {
                        System.out.println("\n--- BFS Traversal ---");
                        System.out.println(String.join(" -> ", order));
                    }
                    break;
                }
                case "9": {
                    System.out.print("Start city for DFS: ");
                    String start = scanner.nextLine().trim();
                    List<String> order = GraphAlgorithms.dfs(graph, start);
                    if (!order.isEmpty()) {
                        System.out.println("\n--- DFS Traversal ---");
                        System.out.println(String.join(" -> ", order));
                    }
                    break;
                }
                case "10": {
                    System.out.print("City name: ");
                    graph.displayNeighbors(scanner.nextLine().trim());
                    break;
                }
                case "11": {
                    System.out.print("City 1: ");
                    String c1 = scanner.nextLine().trim();
                    System.out.print("City 2: ");
                    String c2 = scanner.nextLine().trim();
                    boolean connected = GraphAlgorithms.isConnected(graph, c1, c2);
                    System.out.println("\n[RESULT] " + c1 + " and " + c2 + " are "
                            + (connected ? "CONNECTED" : "NOT CONNECTED") + ".");
                    break;
                }
                case "12": {
                    List<List<String>> components = GraphAlgorithms.connectedComponents(graph);
                    System.out.println("\n--- Connected Components (" + components.size() + ") ---");
                    for (int i = 0; i < components.size(); i++) {
                        System.out.println("  Component " + (i + 1) + ": " + String.join(", ", components.get(i)));
                    }
                    break;
                }
                case "13":
                    System.out.println("\nTotal Cities: " + graph.totalCities());
                    break;
                case "14":
                    System.out.println("\nTotal Roads: " + graph.totalRoads());
                    break;
                case "0":
                    System.out.println("Exiting Smart Map Navigator. Goodbye!");
                    scanner.close();
                    return;
                default:
                    System.out.println("[ERROR] Invalid option. Please try again.");
            }
        }
    }
}
