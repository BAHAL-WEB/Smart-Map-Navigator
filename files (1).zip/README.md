# Smart Map Navigator (Java Version)

Graph-based route planning system using **Dijkstra's Algorithm** (with BFS/DFS
support), inspired by how apps like Google Maps, Uber, and Ola compute
shortest routes.

## Folder Structure
```
SmartMapNavigatorJava/
├── SmartMapNavigator.java  # Menu-driven CLI (entry point / main class)
├── CityGraph.java          # Graph class - cities (nodes) + roads (weighted edges)
├── GraphAlgorithms.java    # BFS, DFS, Dijkstra, connectivity check, connected components
└── README.md
```

## How to Compile & Run
```
javac *.java
java SmartMapNavigator
```

> Note: This was written and reviewed for Java 8+ syntax (uses `java.util`
> collections, lambdas, `String.join`). It was hand-verified against the
> already-tested Python version's logic, since this sandbox only has a JRE
> (no `javac`) and no network access to install a JDK. If you hit any issue
> compiling, let me know and I'll adjust.

The app pre-loads a sample map on startup:
```
Delhi --10-- Noida
Delhi --20-- Gurgaon
Gurgaon --15-- Faridabad
Delhi --200-- Agra
Noida --180-- Agra
```

## Example: Shortest Path
```
Source: Delhi
Destination: Faridabad

--- Shortest Route ---
Delhi
  ↓
Gurgaon
  ↓
Faridabad

Distance = 35.0 KM
```

If a road is removed (e.g. Gurgaon–Faridabad), the next shortest-path query
automatically recalculates using the live graph — no manual refresh needed.

## Data Structures
- **Adjacency List** — `Map<String, Map<String, Double>>` (HashMap of
  HashMaps). Stores each city and its neighbors with distances.
  Memory-efficient for sparse real-world road networks, O(1) average
  lookup per city.
- **Priority Queue** — `java.util.PriorityQueue<QueueEntry>` with a
  `Comparator` on distance. Powers Dijkstra, always expanding the nearest
  unvisited city next.
- **Queue** — `java.util.LinkedList` used as a `Queue<String>` for BFS.
- **Recursion (call stack)** — powers DFS.

## Algorithms
| Algorithm | Purpose                     | Complexity        |
|-----------|------------------------------|--------------------|
| BFS       | Traversal / reachability     | O(V + E)           |
| DFS       | Traversal / components       | O(V + E)           |
| Dijkstra  | Shortest path                | O((V + E) log V)   |

## Features
- Add / Remove / Display Cities
- Add / Remove / Display Roads
- Find Shortest Path (with full route + distance)
- BFS & DFS Traversal
- Neighbor lookup
- Connectivity check between two cities
- Connected components detection
- Total city / road counters

## Extending
- Add persistence (save/load graph via file I/O or JSON, e.g. Gson/Jackson)
- Add a directed-road option for one-way streets
- Swap the CLI for a Spring Boot REST backend + simple web map UI
