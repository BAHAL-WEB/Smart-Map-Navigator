import java.util.*;

/**
 * GraphAlgorithms.java
 * ---------------------
 * BFS      -> Level-order traversal, reachability          O(V + E)
 * DFS      -> Deep traversal, connected components          O(V + E)
 * Dijkstra -> Shortest path using a Priority Queue           O((V + E) log V)
 */
public class GraphAlgorithms {

    // -----------------------------------------------------------------
    // BFS  (uses a Queue)
    // -----------------------------------------------------------------
    public static List<String> bfs(CityGraph graph, String start) {
        List<String> order = new ArrayList<>();
        if (!graph.hasCity(start)) {
            System.out.println("[ERROR] City '" + start + "' does not exist.");
            return order;
        }

        Map<String, Map<String, Double>> adj = graph.getAdjacency();
        Set<String> visited = new HashSet<>();
        Queue<String> queue = new LinkedList<>();

        visited.add(start);
        queue.add(start);

        while (!queue.isEmpty()) {
            String city = queue.poll();
            order.add(city);
            for (String neighbor : adj.get(city).keySet()) {
                if (!visited.contains(neighbor)) {
                    visited.add(neighbor);
                    queue.add(neighbor);
                }
            }
        }
        return order;
    }

    // -----------------------------------------------------------------
    // DFS  (uses recursion / call stack)
    // -----------------------------------------------------------------
    public static List<String> dfs(CityGraph graph, String start) {
        List<String> order = new ArrayList<>();
        if (!graph.hasCity(start)) {
            System.out.println("[ERROR] City '" + start + "' does not exist.");
            return order;
        }
        Set<String> visited = new HashSet<>();
        dfsVisit(graph.getAdjacency(), start, visited, order);
        return order;
    }

    private static void dfsVisit(Map<String, Map<String, Double>> adj, String city,
                                  Set<String> visited, List<String> order) {
        visited.add(city);
        order.add(city);
        for (String neighbor : adj.get(city).keySet()) {
            if (!visited.contains(neighbor)) {
                dfsVisit(adj, neighbor, visited, order);
            }
        }
    }

    // -----------------------------------------------------------------
    // DIJKSTRA - SHORTEST PATH  (uses a Priority Queue / Min-Heap)
    // -----------------------------------------------------------------
    /** A single entry in Dijkstra's priority queue (min-heap). */
    private static class QueueEntry {
        final String city;
        final double distance;

        QueueEntry(String city, double distance) {
            this.city = city;
            this.distance = distance;
        }
    }

    /** Simple holder for the shortest-path result. */
    public static class PathResult {
        public final List<String> path;   // null if unreachable
        public final double distance;      // Double.POSITIVE_INFINITY if unreachable

        public PathResult(List<String> path, double distance) {
            this.path = path;
            this.distance = distance;
        }
    }

    public static PathResult dijkstra(CityGraph graph, String source, String destination) {
        if (!graph.hasCity(source)) {
            System.out.println("[ERROR] Source city '" + source + "' does not exist.");
            return new PathResult(null, Double.POSITIVE_INFINITY);
        }
        if (!graph.hasCity(destination)) {
            System.out.println("[ERROR] Destination city '" + destination + "' does not exist.");
            return new PathResult(null, Double.POSITIVE_INFINITY);
        }

        Map<String, Map<String, Double>> adj = graph.getAdjacency();
        Map<String, Double> distances = new HashMap<>();
        Map<String, String> previous = new HashMap<>();

        for (String city : adj.keySet()) {
            distances.put(city, Double.POSITIVE_INFINITY);
            previous.put(city, null);
        }
        distances.put(source, 0.0);

        // Priority Queue ordered by distance (min-heap)
        PriorityQueue<QueueEntry> pq = new PriorityQueue<>(Comparator.comparingDouble(e -> e.distance));
        pq.add(new QueueEntry(source, 0.0));

        Set<String> visited = new HashSet<>();

        while (!pq.isEmpty()) {
            QueueEntry top = pq.poll();
            double currentDist = top.distance;
            String currentCity = top.city;

            if (visited.contains(currentCity)) continue;
            visited.add(currentCity);

            if (currentCity.equals(destination)) break;

            for (Map.Entry<String, Double> edge : adj.get(currentCity).entrySet()) {
                String neighbor = edge.getKey();
                if (visited.contains(neighbor)) continue;
                double newDist = currentDist + edge.getValue();
                if (newDist < distances.get(neighbor)) {
                    distances.put(neighbor, newDist);
                    previous.put(neighbor, currentCity);
                    pq.add(new QueueEntry(neighbor, newDist));
                }
            }
        }

        if (distances.get(destination) == Double.POSITIVE_INFINITY) {
            return new PathResult(null, Double.POSITIVE_INFINITY);
        }

        // Reconstruct path
        LinkedList<String> path = new LinkedList<>();
        String node = destination;
        while (node != null) {
            path.addFirst(node);
            node = previous.get(node);
        }

        return new PathResult(path, distances.get(destination));
    }

    // -----------------------------------------------------------------
    // CONNECTIVITY CHECK
    // -----------------------------------------------------------------
    public static boolean isConnected(CityGraph graph, String city1, String city2) {
        if (!graph.hasCity(city1) || !graph.hasCity(city2)) return false;
        List<String> reachable = bfs(graph, city1);
        return reachable.contains(city2);
    }

    // -----------------------------------------------------------------
    // CONNECTED COMPONENTS  (uses DFS)
    // -----------------------------------------------------------------
    public static List<List<String>> connectedComponents(CityGraph graph) {
        List<List<String>> components = new ArrayList<>();
        Set<String> visited = new HashSet<>();

        for (String city : graph.getAdjacency().keySet()) {
            if (!visited.contains(city)) {
                List<String> component = dfs(graph, city);
                visited.addAll(component);
                components.add(component);
            }
        }
        return components;
    }
}
