import java.util.*;

/**
 * CityGraph.java
 * ----------------
 * Core Graph data structure for Smart Map Navigator.
 *
 * Cities -> Graph Nodes
 * Roads  -> Weighted Edges
 * Storage -> Adjacency List (HashMap of HashMaps)
 *
 * Adjacency List chosen because:
 *   - Less memory for sparse graphs (real road networks are sparse)
 *   - Faster traversal than adjacency matrix
 *   - O(1) average lookup for a city's neighbors
 */
public class CityGraph {

    // adjacency: { "Delhi" -> {"Noida" -> 10.0, "Gurgaon" -> 20.0} }
    private final Map<String, Map<String, Double>> adjacency = new LinkedHashMap<>();

    // -----------------------------------------------------------------
    // CITY MANAGEMENT
    // -----------------------------------------------------------------
    public boolean addCity(String city) {
        city = city.trim();
        if (adjacency.containsKey(city)) {
            System.out.println("[INFO] City '" + city + "' already exists.");
            return false;
        }
        adjacency.put(city, new LinkedHashMap<>());
        System.out.println("[OK] City '" + city + "' added.");
        return true;
    }

    public boolean removeCity(String city) {
        if (!adjacency.containsKey(city)) {
            System.out.println("[ERROR] City '" + city + "' does not exist.");
            return false;
        }
        // Remove edges pointing to this city from every neighbor
        for (String neighbor : new ArrayList<>(adjacency.get(city).keySet())) {
            adjacency.get(neighbor).remove(city);
        }
        adjacency.remove(city);
        System.out.println("[OK] City '" + city + "' and its roads removed.");
        return true;
    }

    public boolean hasCity(String city) {
        return adjacency.containsKey(city);
    }

    public void displayCities() {
        if (adjacency.isEmpty()) {
            System.out.println("[INFO] No cities in the graph yet.");
            return;
        }
        System.out.println("\n--- Cities ---");
        for (String city : adjacency.keySet()) {
            System.out.println("  * " + city);
        }
        System.out.println("Total Cities: " + adjacency.size());
    }

    public int totalCities() {
        return adjacency.size();
    }

    // -----------------------------------------------------------------
    // ROAD (EDGE) MANAGEMENT
    // -----------------------------------------------------------------
    public boolean addRoad(String city1, String city2, double distance) {
        return addRoad(city1, city2, distance, true);
    }

    public boolean addRoad(String city1, String city2, double distance, boolean bidirectional) {
        if (distance < 0) {
            System.out.println("[ERROR] Distance cannot be negative.");
            return false;
        }
        if (!adjacency.containsKey(city1)) addCity(city1);
        if (!adjacency.containsKey(city2)) addCity(city2);

        adjacency.get(city1).put(city2, distance);
        if (bidirectional) {
            adjacency.get(city2).put(city1, distance);
        }
        System.out.println("[OK] Road added: " + city1 + " <-> " + city2 + " = " + distance + " KM");
        return true;
    }

    public boolean removeRoad(String city1, String city2) {
        return removeRoad(city1, city2, true);
    }

    public boolean removeRoad(String city1, String city2, boolean bidirectional) {
        if (!adjacency.containsKey(city1) || !adjacency.get(city1).containsKey(city2)) {
            System.out.println("[ERROR] No road exists between '" + city1 + "' and '" + city2 + "'.");
            return false;
        }
        adjacency.get(city1).remove(city2);
        if (bidirectional && adjacency.containsKey(city2)) {
            adjacency.get(city2).remove(city1);
        }
        System.out.println("[OK] Road removed: " + city1 + " <-> " + city2);
        return true;
    }

    public void displayRoads() {
        if (adjacency.isEmpty()) {
            System.out.println("[INFO] No roads in the graph yet.");
            return;
        }
        System.out.println("\n--- Roads ---");
        Set<String> seen = new HashSet<>();
        int count = 0;
        for (Map.Entry<String, Map<String, Double>> entry : adjacency.entrySet()) {
            String city = entry.getKey();
            for (Map.Entry<String, Double> edge : entry.getValue().entrySet()) {
                String neighbor = edge.getKey();
                List<String> pair = Arrays.asList(city, neighbor);
                Collections.sort(pair);
                String key = pair.get(0) + "|" + pair.get(1);
                if (seen.contains(key)) continue;
                seen.add(key);
                System.out.println("  " + city + " --- " + edge.getValue() + " KM --- " + neighbor);
                count++;
            }
        }
        System.out.println("Total Roads: " + count);
    }

    public int totalRoads() {
        Set<String> seen = new HashSet<>();
        for (Map.Entry<String, Map<String, Double>> entry : adjacency.entrySet()) {
            for (String neighbor : entry.getValue().keySet()) {
                List<String> pair = Arrays.asList(entry.getKey(), neighbor);
                Collections.sort(pair);
                seen.add(pair.get(0) + "|" + pair.get(1));
            }
        }
        return seen.size();
    }

    // -----------------------------------------------------------------
    // NEIGHBORS
    // -----------------------------------------------------------------
    public Map<String, Double> getNeighbors(String city) {
        if (!adjacency.containsKey(city)) {
            System.out.println("[ERROR] City '" + city + "' does not exist.");
            return null;
        }
        return adjacency.get(city);
    }

    public void displayNeighbors(String city) {
        Map<String, Double> neighbors = getNeighbors(city);
        if (neighbors == null) return;
        if (neighbors.isEmpty()) {
            System.out.println("[INFO] '" + city + "' has no direct roads.");
            return;
        }
        System.out.println("\n--- Neighbors of " + city + " ---");
        for (Map.Entry<String, Double> e : neighbors.entrySet()) {
            System.out.println("  " + city + " --- " + e.getValue() + " KM --- " + e.getKey());
        }
    }

    // Package-private accessor used by GraphAlgorithms
    Map<String, Map<String, Double>> getAdjacency() {
        return adjacency;
    }
}
